<?php
$db_username = "root";
$db_hostname = "localhost";
$db_database = "Youtube_sync";
$db_password = "";


?>