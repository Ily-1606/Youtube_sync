<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
$db_username = "u106559149_syncyoutube";
$db_hostname = "localhost";
$db_database = "u106559149_syncyoutube";
$db_password = "Cunguyen9001";


?>